module.exports = {
  plugins: ["prettier-plugin-tailwindcss"],
  trailingComma: "all",
  singleAttributePerLine: true,
};
